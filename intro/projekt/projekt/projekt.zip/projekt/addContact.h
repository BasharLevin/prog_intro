#ifndef ADDCONTACT_H
#define ADDCONTACT_H
#include <iostream>
#include <string>

void add();

#endif
