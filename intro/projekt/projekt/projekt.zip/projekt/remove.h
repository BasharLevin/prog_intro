#ifndef REMOVE_H
#define REMOVE_H
#include <iostream>
#include <string>

void remove();

#endif
