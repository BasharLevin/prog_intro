#ifndef SEARCH_H
#define SEARCH_H
#include <iostream>
#include <string>

void search();

#endif
